import requests  # pip3 install requests
import json
from pymongo import MongoClient  # pip3 install pymongo
import os

class RadioFetcher:

    def __init__(self):
        self.api_token = ""
        self.refresh_token = os.environ['SPOTIFY_REFRESH_TOKEN']  # allow access to make new api tokens
        self.base_64 = os.environ['SPOTIFY_BASE_64']  # encoded credentials of clientID:clientSecret
        self.playlist_id = os.environ['PLAYLIST_ID']  # US Top 50 Saved playlist id
        self.US_Top_50_id = os.environ['PLAYLIST_ID_UST50']  # US Top 50 playlist id
        self.CONNECTION_STRING = os.environ['MONGO_DB_CONNECTION_STRING']  # for mongoDB connection (google_cloud:AdRAtRmN3oKWBnPg)
        self.database = None  # global data base object
        self.new_songs_dict = dict()  # temp holder for new songs' information {uri: (track, artist)}
        self.song_uris = []  # array of newly found song uris to be added to the playlist at the end of iteration

    def find_new_song_from_UST50(self):  # find the uris of all the songs in UST50 playlist and see if there are new songs. Returns True if it finds anything, else False
        query = f"https://api.spotify.com/v1/playlists/{self.US_Top_50_id}/tracks"  # Get a Playlist's Items
        response = requests.get(query, headers={"Content-Type": "application/json",
                                                "Authorization": f"Bearer {self.api_token}"})
        if response.status_code == 200:  # check if request was a success (200 is success)
            response_json = response.json()
            try:
                self.database = self.get_database()
                collection = self.database["US_Top_50_Saved"]
            except Exception:
                print("error accessing data base")
                return False  # if an error occurs trying to access data base, stop and try again later

            for item in response_json["items"]:  # go through each item in playlist
                track_uri = item["track"]["uri"]
                if not collection.find_one({"track_uri": track_uri}):  # if we find a song that is not added in our playlist...
                    track_name = item["track"]["name"]
                    track_artists = [artist["name"] for artist in item["track"]["artists"]]
                    song_info_tuple = (track_name, track_artists)  # (song name, [song artists])
                    self.new_songs_dict[track_uri] = song_info_tuple  # hold newly found songs in new_songs_dict
        else:
            print("error code:", response.status_code, "had occurred when searching for tracks in UST50 playlist")
            return False
        if len(self.new_songs_dict) != 0:
            self.song_uris = [uri for uri in self.new_songs_dict.keys()]  # create an array of song_uris to be added
            return True
        else:
            return False

    def add_songs_to_playlist(self):  # function adds the list of new song uris to the playlist
        query = f"https://api.spotify.com/v1/playlists/{self.playlist_id}/tracks?position=0"  # Add Items to a Playlist
        request_data = json.dumps(self.song_uris)  # format array of song uris for request data
        response = requests.post(query, data=request_data, headers={"Content-Type": "application/json",
                                                                    "Authorization": f"Bearer {self.api_token}"})
        if response.status_code == 201:  # in case of failure in request (201 is success)
            new_song_documents_array = []  # array of newly found song docs to be added to the data base after being added to the playlist
            for uri in self.new_songs_dict.keys():  # adding the new songs to the main dictionary
                track_name = self.new_songs_dict[uri][0]
                track_artists = self.new_songs_dict[uri][1]
                new_song_document = {  # create new song document to be inserted into the database
                    "track_name": track_name,
                    "track_artists": track_artists,
                    "track_uri": uri,
                    "added_to_playlist": True
                }
                new_song_documents_array.append(new_song_document)
                # self.songs_dict[song] = self.new_songs_dict[song]
            else:
                print("playlist updated - added:", self.new_songs_dict.values())  # values show the song info (no uris)
                collection = self.database["US_Top_50_Saved"]
                collection.insert_many(new_song_documents_array)  # insert new song docs into data base collection
        else:
            print("error code:", response.status_code, "failed to add:", self.new_songs_dict)
        self.song_uris.clear()  # clear song uris after adding them
        self.new_songs_dict.clear()  # clear new_songs dictionary

    def refresh_api(self):  # automatically generate api tokens so it stays authorized forever
        query = "https://accounts.spotify.com/api/token"
        response = requests.post(query, data={"grant_type": "refresh_token", "refresh_token": self.refresh_token},
                                 headers={"Authorization": "Basic " + self.base_64})
        if response.status_code == 200:  # check if request was success (200 is success)
            response_json = response.json()
            self.api_token = response_json["access_token"]  # reset api_token

    def get_database(self):  # returns the mongoDB data base for this project
        client = MongoClient(self.CONNECTION_STRING)
        return client['saved_songs']

def lambda_handler(event, context):
    program = RadioFetcher()
    program.refresh_api()
    if program.find_new_song_from_UST50():
        program.add_song_to_playlist()
